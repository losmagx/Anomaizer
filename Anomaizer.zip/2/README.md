*KPHProxy* is based on [PHProxy](http://sourceforge.net/projects/phproxy/).
I basically wanted a PHProxy on my website with password-protection so I could access it from anywhere and share it with friends by giving them the password.
The password hack-in is just a few lines of code in `index.php.inc.php`.
Be sure to change the default password if you're going to use it on your website.

## License
GPLv2
